public class Bacon implements Ingredients {


	/**
	 * @see Ingredients#taste()
	 * @return
	 */
	public String taste() {
		return "Tomato sauce with Bacon cheese and corn";
	}

}
