public class QuattroFormaggi implements Ingredients {


	/**
	 * @see Ingredients#taste()
	 * @return
	 */
	public String taste() {

		return "4 different tasty cheese types";
	}

}
