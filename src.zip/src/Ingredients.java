public interface Ingredients {

	public abstract String taste();

}
