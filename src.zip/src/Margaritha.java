public class Margaritha implements Ingredients {


	/**
	 * @see Ingredients#taste()
	 * @return
	 */
	public String taste() {

		return "Just tomato sauce";
	}

}
