public abstract class Pizza {

	public Ingredients ingredients;


	public abstract String bake();

}
